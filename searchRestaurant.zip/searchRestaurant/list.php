<!DOCTYPE html>
<html lang="ja">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./src/css/style.css">
    <link rel="stylesheet" href="./src/css/list.css">

    <title>検索結果</title>
    <?php
    // ホットペッパーAPI
    require './vendor/autoload.php';
    $dotenv = Dotenv\Dotenv::createImmutable(__DIR__);
    $dotenv->load();
    $hotpepper_API = $_ENV["HOTPEPPER_API"];
    // データ受け取り
    $latitude =  $_POST['latitude'];
    $longitude = $_POST['longitude'];
    $ranges = $_POST['ranges'];
    $start = $_POST['start'];
    $order = $_POST['order'];
    $budget = $_POST['budget'];
    $api = $hotpepper_API;
    // クエリをまとめる
    $query = [
        'key' => $api,
        'lat' => $latitude,
        'lng' => $longitude,
        'range' => $ranges,
        'start' => $start,
        'order' => $order,
        'budget' => $budget,
        'format' => 'json',
    ];
    // グルメサーチAPIからjsonを取得
    $url = 'https://webservice.recruit.co.jp/hotpepper/gourmet/v1/?';
    $url .= http_build_query($query);
    $response = file_get_contents($url);
    $json = json_decode($response, true);

    //ページネート用API
    if (isset($_POST['page'])) {
        $latitude = $_POST['latitude'];
        $longitude = $_POST['longitude'];
        $range = $_POST['ranges'];
        $order = $_POST['order'];
        $start = $_POST['start'];
        $budget = $_POST['budget'];
        // クエリをまとめる
        $query = [
            'key' => $api,
            'lat' => $latitude,
            'lng' => $longitude,
            'range' => $range,
            'start' => $start,
            'order' => $order,
            'budget' => $budget,
            'count' => 10,
            'format' => 'json',
        ];
        // グルメサーチAPIからjsonを取得
        $url = 'https://webservice.recruit.co.jp/hotpepper/gourmet/v1/?';
        $url .= http_build_query($query);
        $response = file_get_contents($url);
        $json = json_decode($response, true);
    }

    //半径代入
    switch ($ranges) {
        case "1":
            $show_range = "300m";
            break;
        case "2";
            $show_range = "500m";
            break;
        case "3":
            $show_range = "1km";
            break;
        case "4":
            $show_range = "2km";
            break;
        case "5":
            $show_range = "3km";
            break;
    }
    ?>
</head>

<body>
    <header>
        <h1>飲食店を探そう！</a></h1>
        <!-- ページバック -->
        <button onclick="location.href='index.php'" class="btn top_button">Top</button>
    </header>
    <main>
        <?php if ($json['results']['results_available'] == 0) : ?>
        <p class="find font">条件に一致するものが見つかりませんでした…</p>
        <?php else : ?>
        <p class="find font">現在地から半径<?= $show_range; ?>に、<?= $json['results']['results_available']; ?>件あります。</p>
        <?php endif; ?>
        <!-- 並び順 -->
        <?php
        if ($json['results']['results_available'] != 0) : if ($order == "1") :
        ?>
        <p class="font sort_text">名前順で表示</p>
        <?php elseif ($order == "4") : ?>
        <p class="font sort_text">おすすめ順で表示</p>
        <?php else : ?>
        <p class="font sort_text">距離順で表示</p>
        <?php
            endif;
        endif;
        ?>
        <!-- 再検索 -->
        <div class="research">
            <input type="button" value="検索条件変更" onclick="clickBtn()" class="research_button" id="research_button">
            <div id="research_window">
                <form action="list.php" method="POST" class="search_form">
                    <table class="search">
                        <tr>
                            <td class="row" text-align="right">
                                <label class="font label_text">検索範囲</label>
                            </td>
                            <td class="row">
                                <input type="hidden" name="latitude" id="latitude">
                                <input type="hidden" name="longitude" id="longitude">
                                <input type="hidden" value="1" name="start">
                                <input type="hidden" value="10" name="count">
                                <select id="ranges" name="ranges" class="select">
                                    <option value="1">300m</option>
                                    <option value="2">500m</option>
                                    <option value="3">1km</option>
                                    <option value="4">2km</option>
                                    <option value="5">3km</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td class="row" text-align="right">
                                <label class="font label_text">並び</label>
                            </td>
                            <td class="row">
                                <select id="order" name="order" class="select">
                                    <option value="">距離</option>
                                    <option value="4">オススメ</option>
                                    <option value="1">名前</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td class="row" text-align="right">
                                <label class="font label_text">予算</label>
                            </td>
                            <td class="row">
                                <select id="budget" name="budget" class="select">
                                    <option value="">予算を決めてください</option>
                                    <option value="B009">～500円</option>
                                    <option value="B010">501～1000円</option>
                                    <option value="B011">1001～1500円</option>
                                    <option value="B001">1501～2000円</option>
                                    <option value="B002">2001～3000円</option>
                                    <option value="B003">3001～4000円</option>
                                    <option value="B008">4001～5000円</option>
                                    <option value="B004">5001～7000円</option>
                                    <option value="B005">7001～10000円</option>
                                    <option value="B006">10001～15000円</option>
                                    <option value="B012">15001～20000円</option>
                                    <option value="B013">20001～30000円</option>
                                    <option value="B014">30001円～</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2" class="row" text-align="center">
                                <button type="submit" class="font search_button" id="search_button">検索</button>
                            </td>
                        </tr>
                    </table>
                </form>
            </div>
        </div>
        <!-- ページネーション -->
        <div class="pageNation">
            <?php
            if ($json['results']['results_available'] > 10) :
                $i = ceil($json['results']['results_available'] / 10);
                for ($j = 0; $j < $i; $j++) :
            ?>
            <form method="POST" class="search_form">
                <input type="hidden" name="latitude" id="latitude" value="<?= $latitude ?>">
                <input type="hidden" name="longitude" id="longitude" value="<?= $longitude ?>">
                <input type="hidden" name="ranges" value="<?= $ranges; ?>">
                <input type="hidden" name="start" value="<?= $j * 10 + 1; ?>">
                <input type="hidden" name="order" value="<?= $order; ?>">
                <input type="hidden" name="budget" value="<?= $budget; ?>">
                <input type="hidden" value="10" name="count">
                <input type="hidden" value="page" name="page">
                <input class="page_button" value="<?= $j + 1; ?>" type="submit" <?php if ($json['results']['results_start'] == $j * 10 + 1) {
                                                                                            echo "style = 'background-color:rgba(123, 123, 123, 0.755) ;' ";
                                                                                        } ?>>
            </form>
            <?php
                endfor;
            endif;
            ?>
        </div>
        <?php
        for ($k = 0; $k < $json['results']['results_returned']; $k++) :
        ?>
        <div class="card">
            <div class="card_img">
                <img src="<?= $json["results"]["shop"][$k]["logo_image"]; ?>" alt="サムネイル">
            </div>
            <div class="card_content">
                <div class="name">
                    <p class="shop_name"><?= $json["results"]["shop"][$k]["name"]; ?></p>
                </div>
                <table>
                    <tr>
                        <td>
                            <p class=card_title>最寄り駅：</p>
                        </td>
                        <td>
                            <p class="card_text">
                                <?php echo $json["results"]["shop"][$k]["station_name"]; ?>駅</p>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <p class=card_title>アクセス：</p>
                        </td>
                        <td>
                            <p class="card_text">
                                <?php echo $json["results"]["shop"][$k]["access"]; ?></p>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <p class=card_title>平均予算：</p>
                        </td>
                        <td>
                            <p class="card_text"><?= $json["results"]["shop"][$k]["budget"]["average"]; ?></p>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <p class=card_title>メッセージ：</p>
                        </td>
                        <td>
                            <p class="card_text"><?= $json["results"]["shop"][$k]["catch"]; ?></p>
                        </td>
                    </tr>
                    <tr>
                        <td class="btn" colspan="2">
                            <form action="./detailRestaurant.php" method="POST">
                                <input type="hidden" value="<?= $json["results"]["shop"][$k]["id"]; ?>" name="id">
                                <input type="submit" value="詳細" class="detail_button">
                            </form>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
        <?php endfor; ?>
        <!-- ページネーション -->
        <div class="pageNation">
            <?php
            if ($json['results']['results_available'] > 10) :
                $i = ceil($json['results']['results_available'] / 10);
                for ($j = 0; $j < $i; $j++) :
            ?>
            <form method="POST" class="search_form">
                <input type="hidden" name="latitude" id="latitude" value="<?= $latitude ?>">
                <input type="hidden" name="longitude" id="longitude" value="<?= $longitude ?>">
                <input type="hidden" name="ranges" value="<?= $ranges; ?>">
                <input type="hidden" name="start" value="<?= $j * 10 + 1; ?>">
                <input type="hidden" name="order" value="<?= $order; ?>">
                <input type="hidden" name="budget" value="<?= $budget; ?>">
                <input type="hidden" value="10" name="count">
                <input type="hidden" value="page" name="page">
                <input class="page_button font" value="<?= $j + 1; ?>" type="submit" <?php if ($json['results']['results_start'] == $j * 10 + 1) {
                                                                                                    echo "style = 'background-color:rgba(123, 123, 123, 0.755) ;' ";
                                                                                                } ?>>
            </form>
            <?php
                endfor;
            endif;
            ?>
        </div>
        <!-- ページバック -->
        <?php if ($json['results']['results_available'] > 10) : ?>
        <button class="top_button" id="page-top"><a href="#">上に戻る</a></button>
        <?php endif; ?>
    </main>
    <footer>
        <p>Powered by <a href="http://webservice.recruit.co.jp/" class="footer_link">ホットペッパーWebサービス</a>
            <br>
            Copyright © 2022 Issei Furutani
        </p>
    </footer>

    <script>
    //初期表示は非表示
    const research_window = document.getElementById("research_window");
    const research_button = document.getElementById("research_button");
    research_window.style.display = "none";

    function clickBtn() {
        if (research_window.style.display == "block") {
            research_window.style.display = "none";
            research_button.value = "検索条件変更";
        } else {
            research_window.style.display = "block";
            research_button.value = "閉じる";
        }
    }
    </script>
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"
        integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous">
    </script>
    <script src="./src/js/scrollTop.js"></script>

</body>

</html>