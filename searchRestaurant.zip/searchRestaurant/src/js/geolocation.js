load = document.getElementById("load");
const search_button = document.getElementById("search_button");
load.textContent = "Locating…";

//位置情報取得までボタン操作禁止
search_button.disabled = true;

// ブラウザがGeolocation APIに対応しているかをチェック
if (navigator.geolocation) {
    // 現在地を取得
    navigator.geolocation.getCurrentPosition(
        function success(position) {
            const latitude = position.coords.latitude; // 緯度取得
            const longitude = position.coords.longitude; // 経度取得
            document.getElementById("latitude").value = latitude;
            document.getElementById("longitude").value = longitude;

            load.textContent=`現在地は緯度:${latitude}  経度:${longitude}です。`;
            search_button.disabled=false;
        },
        function (error) {
            switch (error.code) {
        case 0: // 0:UNKNOWN_ERROR
            load.textContent = "原因不明のエラーが発生しました。";
            break;

        case 1: // 1:PERMISSION_DENIED
            load.textContent = "位置情報の取得が許可されませんでした。";
            break;

        case 2: // 2:POSITION_UNAVAILABLE
            load.textContent = "電波状況などで位置情報が取得できませんでした。";
            break;

        case 3: // 3:TIMEOUT
            load.textContent = "位置情報の取得に時間がかかり過ぎてタイムアウトしました。";
            break;
        }
        } ,
        {
        "enableHighAccuracy": false,
        "timeout": 8000,
        "maximumAge": 2000,
        }
    );
} else {
    // エラーメッセージ
    const errorMessage = "お使いの端末は、GeoLocation APIに対応していません。" ;
    // アラート表示
    alert( errorMessage ) ;
    // HTMLに書き出し
    document.getElementById( 'result' ).innerHTML = errorMessage ;
}
